﻿using CrudAPI.API.DataContext;
using CrudAPI.API.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;


namespace CrudAPI.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly JwtOptions _options;
        public AuthController(AppDbContext context, IOptions<JwtOptions> options)
        {
            _context = context;
            _options = options.Value;

        }

        [HttpPost("Login")]
        public async Task<IActionResult> loginUser([FromBody] Login userlogin)
        {
            if (userlogin == null)
            {
                return BadRequest();
            }

            var username = await _context.Users.FirstOrDefaultAsync(s => s.Email == userlogin.Email);

            if (username == null)
            {
                return BadRequest("username not registered");
            }

            var dbPass = username.Password;
            var sha1 = System.Security.Cryptography.SHA1.Create();
            var hash = sha1.ComputeHash(Encoding.UTF8.GetBytes(userlogin.Password));
            userlogin.Password = Convert.ToBase64String(hash);

            if (dbPass != userlogin.Password)
            {
                return BadRequest("Incorrect email or pass");
            }
            var token = GetJWTToken(userlogin.Email);
            return Ok(new { token = token });

        }
        private string GetJWTToken(string username)
        {
            var jwtKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_options.key));
            var crendential = new SigningCredentials(jwtKey, SecurityAlgorithms.HmacSha256);
            List<Claim> claims = new List<Claim>()
            {
                new Claim("Username",username)
            };
            var sToken = new JwtSecurityToken(_options.key, _options.Issuer, claims, expires: DateTime.Now.AddHours(5), signingCredentials: crendential);
            var token = new JwtSecurityTokenHandler().WriteToken(sToken);
            return token;
        }
        [HttpPost("signup")]
        public async Task<IActionResult> Signup([FromBody] User user)
        {
            if (user == null)
            {
                return BadRequest("Invalid User Data ");
            }
            var sha1 = System.Security.Cryptography.SHA1.Create();

            var hash = sha1.ComputeHash(Encoding.UTF8.GetBytes(user.Password));
            user.Password = Convert.ToBase64String(hash);

            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return Ok(new { Message = "User Added Successfully" });
        }
    }
}
