﻿using CrudAPI.API.DataContext;
using CrudAPI.API.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CrudAPI.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly AppDbContext _context;
        public ProductsController(AppDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<IActionResult> GetProducts()
        {
            var products = await _context.Products.ToListAsync();
            return Ok(products);
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetProductById(int id)
        {
            var prod = await _context.Products.FirstOrDefaultAsync(x => x.Id == id);
            if (prod == null)
            {
                return NotFound();
            }
            return Ok(prod);
        }

        [HttpPost]
        public async Task<IActionResult> AddProduct([FromBody] Product product)
        {
            if(product == null)
            {
                return BadRequest("Invalid Product Data ");
            }
            _context.Products.Add(product);
            await _context.SaveChangesAsync();
            return Ok(new { Message = "Product added successfully" });

        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var product = _context.Products.Find(id);
            if(product == null)
            {
                return NotFound();
            }
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
            return Ok(new {Message = "Product Successfully Deleted"});
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProduct(int id, [FromBody] Product UpdatedProduct)
        {
            var existingProduct = await _context.Products.FindAsync(id);
            if(existingProduct == null)
            {
                return NotFound();
            }
            existingProduct.Name = UpdatedProduct.Name;
            existingProduct.price = UpdatedProduct.price;
            //existingProduct.CreatedAt = UpdatedProduct.CreatedAt;

            await _context.SaveChangesAsync();
            return Ok(new { Message = "Product Updated Successfully"});
        }
    }
}
