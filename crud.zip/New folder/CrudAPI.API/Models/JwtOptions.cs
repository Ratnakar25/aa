﻿namespace CrudAPI.API.Models
{
    public class JwtOptions
    {
        public string key {  get; set; }
        public string Issuer { get; set; }
    }
}
