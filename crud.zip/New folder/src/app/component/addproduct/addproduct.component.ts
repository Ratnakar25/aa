import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/product/product';
import { ProductService } from 'src/app/product/product.service';
import { Router } from '@angular/router';

@Component({
 selector: 'app-addproduct',
 templateUrl: './addproduct.component.html',
 styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {
 formdata: Product = {
    name: '',
    price: 0,
    CreatedAt: ''
 };

 constructor(private router: Router, private prod: ProductService) { }

 ngOnInit(): void {
 }

 postData() {
  this.formdata.CreatedAt = new Date().toISOString();

  console.log(this.formdata);
  

    this.prod.addProduct(this.formdata)
      .subscribe({
        next: data => {
          alert("Product Added");
          this.router.navigateByUrl("/");
        },
        error: err => {
          console.log(err);
        }
      });
 }
}
