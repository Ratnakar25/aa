import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/product/product.service';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-editproduct',
  templateUrl: './editproduct.component.html',
  styleUrls: ['./editproduct.component.css']
})
export class EditproductComponent implements OnInit {
  formdata = {
    name:'',
    price:0
  }
 
  id = null
 
  constructor(private prod:ProductService, private router:Router, private activated_router:ActivatedRoute) {
 
    this.activated_router.params.subscribe({
      next:(val)=>{
        this.id = val['id']
      }
    })
 
   }
 
  ngOnInit(): void {
    this.prod.getProductById(this.id).subscribe({
      next:(data)=>{
        this.formdata = data
      }
    })
  }
 
  postData(){
    this.prod.editProduct(this.id,this.formdata).subscribe({
      next:(val)=>{
        this.router.navigateByUrl('/')
      }
    })
  }
 

}
