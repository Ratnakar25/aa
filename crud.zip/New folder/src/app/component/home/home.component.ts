import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/product/product.service';
import { Product } from 'src/app/product/product';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  allProducts:Product[]=[];
  constructor(private prod:ProductService) { }

  ngOnInit(): void {
    this.prod.getProducts()
    .subscribe({
       next:data=>{
         console.log(data)
         this.allProducts=data;
       },
       error:err=>{
         console.log(err)
       }
    })
  }
  delPro(id: any) {
    console.log(id);
   
    this.prod.delProduct(id)
       .subscribe({
         next: data => {
           if (data) {
             console.log(data);
             alert("Product Deleted");
             this.allProducts = this.allProducts.filter(prod => prod.id != id);
           }
         },
         error: err => {
           console.log(err);
         }
       });
   }
   

}
