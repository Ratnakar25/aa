import { Component, OnInit, Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-listitems',
  templateUrl: './listitems.component.html',
  styleUrls: ['./listitems.component.css']
})
export class ListitemsComponent implements OnInit {
  @Input() prodata:any;
  @Output() deleteProduct=new EventEmitter();
  constructor() { }

  ngOnInit(): void {
  }
  delProd(id:any){
     if(confirm("Do u want to delete ?")){
       this.deleteProduct.emit(id)
      //  console.log(id);
       
     }
  }
}
