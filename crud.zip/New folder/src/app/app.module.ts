import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddproductComponent } from './component/addproduct/addproduct.component';
import { HttpClient, HttpClientModule } from  "@angular/common/http";
import {FormsModule}  from "@angular/forms";
import { HomeComponent } from './component/home/home.component';
import { EditproductComponent } from './component/editproduct/editproduct.component';
import { ListitemsComponent } from './component/listitems/listitems.component';
import { NavComponent } from './component/nav/nav.component'

@NgModule({
  declarations: [
    AppComponent,
    AddproductComponent,
    HomeComponent,
    EditproductComponent,
    ListitemsComponent,
    NavComponent,FormsModule,HttpClientModule,HttpClient
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
