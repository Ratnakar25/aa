import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddproductComponent } from './component/addproduct/addproduct.component';
import { HomeComponent } from './component/home/home.component';
import { EditproductComponent } from './component/editproduct/editproduct.component';

const routes: Routes = [
  { path: '', component:HomeComponent, pathMatch: 'full' },
  {path:"addproduct", component:AddproductComponent},
  {path:"editproduct/:id",component:EditproductComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
