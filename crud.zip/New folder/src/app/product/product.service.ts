import { HttpClient,HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

const API_URL="https://localhost:7048/api/Products";

import { Product } from './product';
@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http:HttpClient) { }
  //get all products 
  getProducts(){
      return this.http.get<Product[]>(API_URL);
  }
   addProduct(payload:Product){
    return this.http.post<Product>(API_URL,payload)
 }
 delProduct(id:number){ 
  return this.http.delete(`${API_URL}/${id}`);
 }
 getProductById(id:any){
  return this.http.get<Product>(`${API_URL}/${id}`);
 }
 editProduct(id:any,payload:Product){
  return this.http.put(`${API_URL}/${id}`,payload)
}
 
}
