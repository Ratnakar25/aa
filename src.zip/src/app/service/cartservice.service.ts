import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CartItem } from '../user/user';

@Injectable({
 providedIn: 'root'
})
export class CartserviceService {
   itemcount:number=0
   private totalPriceSource = new BehaviorSubject<number>(0);
   currentTotalPrice = this.totalPriceSource.asObservable();

   private cartItemsSource = new BehaviorSubject<CartItem[]>([]);
   currentCartItems = this.cartItemsSource.asObservable();

 private cart = new BehaviorSubject<any[]>([]);

 constructor() {}
 updateTotalPrice(price: number) {
   this.totalPriceSource.next(price);
}



getTotalPrice() {
   return this.totalPriceSource.getValue();
}

updateCartItems(items: CartItem[]){
   this.cartItemsSource.next(items);
   localStorage.setItem("shopping-cart",JSON.stringify(items))
   console.log(items);
}



getCartItems() {
   return this.cartItemsSource.getValue();
}

addProduct(product: any) {
   const currentCart = this.cart.getValue();
   this.cart.next([...currentCart, product]);
   this.itemcount =  this.cart.value.length;
   this.updateCartItems(this.cart.value);
}

 getCart() {
    return this.cart.asObservable();
 }
}
