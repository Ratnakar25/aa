import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
const url='http://localhost:3003/user'
import { User } from '../user/user';

@Injectable({
  providedIn: 'root'
})

export class UserserviceService {
  constructor(private http:HttpClient,private router:Router) { }
  getUsers(){
    return this.http.get<User[]>(url);
  }

  login(email:string,password:string){
    this.getUsers().subscribe({
      next:(users)=>{
        let user = users.find(user=>user.email==email  && user.password == password);
        if(user){
          localStorage.setItem("isLogged", "true");
          localStorage.setItem("user",JSON.stringify(user));
          alert("Login Successful")
          this.router.navigateByUrl('/menu')
        }else{alert("Login UnsuCCessful")}
        
    
      }
    })
  }
  logout(){
    localStorage.removeItem('user');
    this.router.navigateByUrl('/login')
  }
  
}
