import { Injectable } from '@angular/core';
import { Users, loginUser } from './users';
import { HttpClient } from '@angular/common/http';


const API_URL_signup="https://localhost:7048/api/Auth/signup";
const API_URL_login="https://localhost:7048/api/Auth/login";


@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private http:HttpClient) { }
  addUser(payload:Users){
    return this.http.post<Users>(API_URL_signup,payload)
 }
 checkLogin(payload:loginUser){
  return this.http.post<loginUser>(API_URL_login,payload)
}
}
