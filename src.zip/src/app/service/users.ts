export interface Users {
    Id?:number,
    Name:string,
    Email:string,
    Password:string,
    Mobile:string
}
export interface loginUser{
    Email:string,
    Password:string,
    token:any,
    error:any
}
