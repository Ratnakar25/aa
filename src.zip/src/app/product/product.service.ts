import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Product } from './product';

const api = 'http://localhost:3002/products';
@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http:HttpClient) { }

  getProducts(){
    return this.http.get<Product[]>(api);
  }
  addProduct(payload:Product){
    return this.http.post<Product>(api,payload)
 }
 
}
