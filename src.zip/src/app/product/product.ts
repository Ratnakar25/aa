// model for product

export interface Product {
    id?:number,
    name:string,
    quantity:number,
    price:number,
    image:any
}
