export interface signupUser {
    id?:number,
    fullName:string,
    email:string,
    password:string
}
export interface User {
    id?:number,
    email:string,
    password:string
}
export interface cardData {
    cardNumber:string
    expiryDate:string,
      cvv: string
}

export interface CartItem{
    name: string;
    image: string;
    price: number;
    quantity: number;
}
