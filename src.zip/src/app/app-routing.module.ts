import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './component/home/home.component';
import { LoginComponent } from './component/login/login.component';
import { SignupComponent } from './component/signup/signup.component';
import { MenuComponent } from './component/menu/menu.component';
import { ShoppingCartComponent } from './component/shopping-cart/shopping-cart.component';
import { ProfileComponent } from './component/profile/profile.component';
import { NotFoundComponent } from './component/not-found/not-found.component';
import { CheckoutComponent } from './component/checkout/checkout.component';
import { ThankyoupageComponent } from './component/thankyoupage/thankyoupage.component';

const routes: Routes = [
  {path:"",component:HomeComponent},
  {path:"login",component:LoginComponent},
  {path:"menu",component:MenuComponent},
  {path:"shopping",component:ShoppingCartComponent},
  {path:"signup",component:SignupComponent},
  {path:"profile",component:ProfileComponent},
  {path:"checkout",component:CheckoutComponent},
  {path:"thankyou",component:ThankyoupageComponent},
  {path:"**", component:NotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
