import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User, signupUser } from 'src/app/user/user';
import { UserService } from 'src/app/user/user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  
  formData:signupUser={
    fullName:'',
    email:'',
    password:''

  }

  constructor(private router:Router,private prod:UserService) { }

  ngOnInit(): void {
  }
  postData(){
    this.prod.addUser(this.formData)
    .subscribe({
      next:data=>{
        alert("User Added");
        this.router.navigateByUrl("/menu")
      },
      error:err=>{
        console.log(err)
      }
    })
  }

}
