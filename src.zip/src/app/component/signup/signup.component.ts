import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Users } from 'src/app/service/users';
import { UsersService } from 'src/app/service/users.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
formdata:Users={
  Name:'',
    Email:'',
    Password:'',
    Mobile:''
};
  constructor(private route:Router,private users:UsersService) { }

  ngOnInit(): void {
  }

  postData(){
    this.users.addUser(this.formdata)
    .subscribe({
      next: data => {
        alert("User Added");
        this.route.navigateByUrl("/login");
      },
      error: err => {
        console.log(err);
      }
    });
  }

}
