import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/product/product';
import { ProductService } from 'src/app/product/product.service';
import { CartserviceService } from 'src/app/service/cartservice.service';
import {  CartItem } from 'src/app/user/user';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

@Component({
 selector: 'app-shopping-cart',
 templateUrl: './shopping-cart.component.html',
 styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit {
totalPrice:number=0

productsInCart:number=0
   allProducts:Product[]=[]
   cartProducts:CartItem[]=[]
   constructor(private prod:ProductService,private cartService: CartserviceService,private route:Router) { 
      this.cartService.updateCartItems(this.cartProducts);
   }

 ngOnInit(): void {
   this.cartService.updateCartItems(this.cartProducts);
   this.cartService.getCart().subscribe(products => {
      // console.log(this.cartProducts)
      this.cartProducts = products;
      this.calculateTotalPrice();
      this.cartService.updateCartItems(this.cartProducts);
      
    });
    
 }
 calculateTotalPrice(): void {
   this.totalPrice = this.cartProducts.reduce((total, item) => total + (item.price * item.quantity), 0);
   console.log(this.totalPrice);
   this.productsInCart = this.cartProducts.length;
   this.cartService.updateCartItems(this.cartProducts);

  }
  

DeleteItem(cartItem: CartItem): void {
   const index = this.cartProducts.indexOf(cartItem);
   if (index > -1) {
     this.cartProducts.splice(index, 1);
     this.calculateTotalPrice();
     this.cartService.updateCartItems(this.cartProducts);
   }
}

increaseQuantity(cartItem: CartItem): void {
   if (cartItem?.quantity !== undefined) {
      cartItem.quantity++;
      this.calculateTotalPrice();
      this.cartService.updateCartItems(this.cartProducts);
   }
  }
  
  decreaseQuantity(cartItem: CartItem): void {
   if (cartItem?.quantity !== undefined && cartItem.quantity > 1) {
      cartItem.quantity--;
      this.calculateTotalPrice();
      this.cartService.updateCartItems(this.cartProducts);
   }
  }

  toPayment(){
   this.cartService.updateTotalPrice(this.totalPrice);
   this.cartService.updateCartItems(this.cartProducts);
   this.route.navigateByUrl('/checkout')
  }
  
  
}


