import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { CartserviceService } from 'src/app/service/cartservice.service';
import { UserserviceService } from 'src/app/service/userservice.service';
import { CartItem } from 'src/app/user/user';

@Component({
 selector: 'app-navbar',
 templateUrl: './navbar.component.html',
 styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
 isLoggedIn: boolean = false;
 cartItemCount:number=0;
 cartProducts:CartItem[]=[]

 constructor(private userService: UserserviceService, private router: Router,private cartService:CartserviceService) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.updateLoginStatus();
      }
    });
 }

 ngOnInit(): void {
    this.updateLoginStatus();
    const cartItems = JSON.parse(localStorage.getItem('shopping-cart')||'[]');
    this.cartItemCount = cartItems.length;
    this.cartService.currentCartItems.subscribe(items => {
      this.cartItemCount = items.length;
   });
   
 }

 updateLoginStatus(): void {
    const user = localStorage.getItem('user');
    this.isLoggedIn = !!user;
 }

 handleLogout(): void {
    this.userService.logout();
    this.updateLoginStatus();
 }
 updateCart(){
   this.cartService.updateCartItems(this.cartProducts);
 }
}
