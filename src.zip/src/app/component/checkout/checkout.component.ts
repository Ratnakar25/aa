import { Component, OnInit } from '@angular/core';
import { cardData } from 'src/app/user/user';
import { CartserviceService } from 'src/app/service/cartservice.service';
import { Router } from '@angular/router';

@Component({
 selector: 'app-checkout',
 templateUrl: './checkout.component.html',
 styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  orderprice:number=0;
checkoutForm: cardData = {
 cardNumber:'', 
 expiryDate: '',
 cvv: ''
}

 constructor(private pri:CartserviceService,private route:Router) {
  this.pri.currentTotalPrice.subscribe(totalPrice=>{
    console.log(totalPrice);
    this.orderprice=totalPrice;
  })
  }

 ngOnInit(): void {
    
 }
 toThankYou(){
this.route.navigateByUrl('/thankyou')
 }
 postData(){}

 
}
