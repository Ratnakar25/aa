import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/product/product.service';
import { Product } from 'src/app/product/product';
import { CartserviceService } from 'src/app/service/cartservice.service';
import { Route, Router } from '@angular/router';
import { CartItem } from 'src/app/user/user';
@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  allProducts:Product[]=[]
  cartProducts:CartItem[]=[]
  constructor(private prod:ProductService,private cartService: CartserviceService, private route:Router) { }

  ngOnInit(): void {
   this.prod.getProducts()
   .subscribe({
      next:data=>{
        console.log(data)
        this.allProducts=data;
      },
      error:err=>{
        console.log(err)
      }
   })
 }
 addToCart(product: any) {
   this.cartService.addProduct(product);
   alert("Added to Cart")
   this.updateCart();
   // console.log(product);
  //  this.route.navigateByUrl('/shopping').then(()=>{
  //   // window.location.reload()
  //  });
}
updateCart(){
  this.cartService.updateCartItems(this.cartProducts);

}

}




