import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserserviceService } from 'src/app/service/userservice.service';
import { User } from 'src/app/user/user';
import { UserService } from 'src/app/user/user.service';

@Component({
 selector: 'app-login',
 templateUrl: './login.component.html',
 styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
 formData= {
    email: '',
    password: ''
 }

 constructor(private userSer: UserserviceService) { }

 ngOnInit(): void {
 }
 handleSubmit(){
  this.userSer.login(this.formData.email,this.formData.password);
 }


}
