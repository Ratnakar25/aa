import { Component, OnInit } from '@angular/core';
import { Users, loginUser } from 'src/app/service/users';
import { UsersService } from 'src/app/service/users.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  formdata:loginUser = {
    Email:'',
    Password:'',
    token:'',
    error:''
  }

  constructor(private route:Router,private users:UsersService) { }

  ngOnInit(): void {
  }
  postData(){
    this.users.checkLogin(this.formdata)
    .subscribe({
      
      next: data => {
          console.log(data);
          
          // if(localStorage.getItem('Token')){
          //   alert("session already exists")
          // }
          
          localStorage.setItem('Token',data.token)
        },
        error: err => {
          console.error(err);
          alert("An error occurred. Please try again.");
        }
    });
   }
     
   
   
   

}
